package com.example.webservice;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class Adaptador extends ArrayAdapter<Users> {

    Context context;
    List<Users>arrayaListaUsers;
    public Adaptador(@NonNull Context context, List<Users> arrayaListaUsers) {
        super(context, R.layout.my_list_item,arrayaListaUsers);

        this.context = context;
        this.arrayaListaUsers = arrayaListaUsers;

    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_list_item,null,true);

        TextView tvID = view.findViewById(R.id.txt_id);
        TextView tvName = view.findViewById(R.id.txt_nombre);

        tvID.setText(arrayaListaUsers.get(position).getId());
        tvName.setText(arrayaListaUsers.get(position).getNombre());

        return view;
    }

}
